fbFriends = int(input("How many Facebook friends do you have? "))

if fbFriends >= 500:
    print ("Looks like you are an extrovert!")
elif fbFriends >= 200 and fbFriends < 500:
    print ("Looks like you are average!")
elif fbFriends >= 50 and fbFriends < 200:
    print ("Looks like you are an introvert!")
elif fbFriends >= 1 and fbFriends < 50:
    print ("Looks like you are a loner!")
elif fbFriends >= 0:
    print ("Looks like you are dangerously antisocial. Perhaps a therapist is in order...")
