i = 0
while i < 100:
    print("Repetition is fun!")
    i = i + 1
