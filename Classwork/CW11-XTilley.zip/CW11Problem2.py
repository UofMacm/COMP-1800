i = 0
while i < 100:
    i = i + 1
    print(str(i) + " - Repetition is fun!")
