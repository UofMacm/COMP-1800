i = 0
while i == 0:
    print("I will not \"let the dogs out\"")
    
