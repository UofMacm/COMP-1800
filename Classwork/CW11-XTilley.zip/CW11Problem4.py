j = 0
while j < 50:
    i = 2
    while i <= 28:
        print(i)
        i = i + 2
    print("Who do we appreciate?")
    j = j + 1

