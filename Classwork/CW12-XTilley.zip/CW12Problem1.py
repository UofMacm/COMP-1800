i = 0
n = 1
while i < 100:
    print(n)
    n = n * 3
    i = i + 1
