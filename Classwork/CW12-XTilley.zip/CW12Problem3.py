i = 0
n = 0
difference = 1
while i < 100:
    print(n)
    n = n + difference
    difference = difference + 1
    i = i + 1
