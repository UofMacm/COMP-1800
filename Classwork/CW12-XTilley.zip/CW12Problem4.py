i = 1
while i <= 100:
    print(i)
    if i % 2 == 0:
        i = i * -1 + 1
    else:
        i = i * -1 - 1
