n = int(input("How many grades do you want to find the minimum from? "))
i = 0
minGrade = 101
while i < n:
    nextGrade = float(input("What's the next grade? "))
    if nextGrade < minGrade:
        minGrade = nextGrade
    i = i + 1

print("The min grade is: " + str(minGrade))
