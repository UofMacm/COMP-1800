n = int(input("How many grades do you want to average? "))

sumGrades = 0
minGrade = 101
i = 0
while i < n:
    nextGrade = float(input("What's the next grade you want to average? "))
    if nextGrade < minGrade:
        minGrade = nextGrade
    sumGrades = sumGrades + nextGrade
    i = i + 1

average = (sumGrades - minGrade)/(n - 1)
print("The average is " + str(average))
