def fgPoints(distance):
    if distance >= 23.75:
        return 3
    else:
        return 2

d = float(input("What was the distance in feet? "))
print(fgPoints(d))


          
