def computeTaxes(income):
    if income <= 5000:
        tax = 0
    elif income > 5000 and income <= 20000:
        tax = (income - 5000)*0.1
    elif income > 20000:
        tax = 15000*0.1 + (income-20000)*0.15
    return tax




    
income = int(input("how much is your income?"))
print(computeTaxes(income))
