sleep = float(input("How many hours of sleep did you get last night? "))

if sleep >= 6.0:
    print("Great, you should be good to go!")
else:
    print("You might need an extra shot of esspresso in your coffee today.")
              
