age = int(input("How old are you? "))
print ("You are eligible to serve in the following offices: ")
if age >= 25:
    print ("House")
    if age >= 30:
        print ("Senate")
        if age >= 35:
            print ("President")
