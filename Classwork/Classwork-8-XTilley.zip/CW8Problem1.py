#Xavier Tilley

#Gather input and declare variables
usDollars = float(input("Enter the amount of U.S. money in dollars: "))
exchangeRate = 101.05

#Do math stuff
yen = usDollars*exchangeRate

#Print stuff
print("You have ", str(yen), "yen to spend in Japan!")

    
