#Xavier Tilley

#Inputpalooza
string = input("Enter a string: ")
repeats = int(input("How many times do you want to print that? "))

#Printpalooza
print((string + "\n\n") *repeats)
