# User Input
creditHours = int(input("How many credit hours are you taking? "))
engSciHours = int(input("How many of those are for Engineering or Science classes? "))

# Tution Cost
if creditHours <= 12:
    tuition12 = creditHours * 350
    engSciTuition = engSciHours * 25
    totalTuition12 = tuition12 + engSciTuition
    print("Tuition                          =     " + str(tuition12))
    print("Engineering and Science Fees     =     " + str(engSciTuition))
    print("Total                            =     " + str(totalTuition12))
elif creditHours > 12:
    extraHours = creditHours - 12
    tuitionExtra = extraHours * 40
    tuitionTotal = tuitionExtra + (350 * 12)
    engSciTuitionExtra = engSciHours * 25
    totalTuitionExtra = tuitionExtra + engSciTuitionExtra + (350 * 12)
    print("Tuition                          =     " + str(tuitionTotal))
    print("Engineering and Science Fees     =     " + str(engSciTuitionExtra))
    print("Total                            =     " + str(totalTuitionExtra))
else:
    print("Error")
