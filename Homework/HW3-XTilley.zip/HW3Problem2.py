print("What Type of Car Are You? \n Answer the following questions on a \n scale of Strongly Disagree to Strongly Agree.")

# Question 1
print("I am a risk taker.")
print("1. Strongly disagree")
print("2. Disagree")
print("3. Neither agree nor disagree")
print("4. Agree")
print("5. Strongly agree")

q1 = int(input("Which number best discribes you?"))

# Question 2
print("I like wearing fancy clothes.")
print("1. Strongly disagree")
print("2. Disagree")
print("3. Neither agree nor disagree")
print("4. Agree")
print("5. Strongly agree")

q2 = int(input("Which number best discribes you?"))

# Question 3
print("I value appearance over practicality.")
print("1. Strongly disagree")
print("2. Disagree")
print("3. Neither agree nor disagree")
print("4. Agree")
print("5. Strongly agree")

q3 = int(input("Which number best discribes you?"))

# Question 4
print(" I don't mind spending my money freely.")
print("1. Strongly disagree")
print("2. Disagree")
print("3. Neither agree nor disagree")
print("4. Agree")
print("5. Strongly agree")

q4 = int(input("Which number best discribes you?"))

# Question 5
print("I consider myself a fun-loving person.")
print("1. Strongly disagree")
print("2. Disagree")
print("3. Neither agree nor disagree")
print("4. Agree")
print("5. Strongly agree")

q5 = int(input("Which number best discribes you?"))

# Calculating results

questionTotal = q1 + q2 + q3 + q4 + q5

if questionTotal >= 21:
    print("You are an exotic convertible!")

elif questionTotal >= 11 and questionTotal < 21:
    print("You are a sporty compact!")

else:
    print("You are a family sedan!")
    
