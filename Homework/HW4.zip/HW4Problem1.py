print("Welcome to World of TextCraft! \n------------------------------")
x = 0
y = 0
print ("You are currently at (" + str(x) + "," + str(y) + ")")
direction = int(input("Enter command (1 = North, 2 = East, 3 = South, 4 = West, 5 = Exit)"))
while direction < 5:
    if direction == 1:
        y = y + 1
        print ("Moving North")
        print ("You are currently at (" + str(x) + "," + str(y) + ")")
        direction = int(input("Enter command (1 = North, 2 = East, 3 = South, 4 = West, 5 = Exit)"))
    elif direction == 2:
        x = x + 1
        print ("Moving East")
        print ("You are currently at (" + str(x) + "," + str(y) + ")")
        direction = int(input("Enter command (1 = North, 2 = East, 3 = South, 4 = West, 5 = Exit)"))
    elif direction == 3:
        y = y - 1
        print ("Moving South")
        print ("You are currently at (" + str(x) + "," + str(y) + ")")
        direction = int(input("Enter command (1 = North, 2 = East, 3 = South, 4 = West, 5 = Exit)"))
    elif direction == 4:
        x = x - 1
        print ("Moving West")
        print ("You are currently at (" + str(x) + "," + str(y) + ")")
        direction = int(input("Enter command (1 = North, 2 = East, 3 = South, 4 = West, 5 = Exit)"))
    elif direction == 5:
        print("Thank you for playing!")
    else:
        print("Would you like to choose a more realistic direction?")
        direction = int(input("Enter command (1 = North, 2 = East, 3 = South, 4 = West, 5 = Exit)"))
