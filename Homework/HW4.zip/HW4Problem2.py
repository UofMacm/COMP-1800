vote = int(input("Enter the ID number of the candidate (1-5, 0 to exit) : "))
candidate1 = 0
candidate2 = 0
candidate3 = 0
candidate4 = 0
candidate5 = 0
while vote > 0 or vote < 0:
    if vote == 1:
        candidate1 = candidate1 + 1
        vote = int(input("Enter the ID number of the candidate (1-5, 0 to exit) : "))
    elif vote == 2:
        candidate2 = candidate2 + 1
        vote = int(input("Enter the ID number of the candidate (1-5, 0 to exit) : "))
    elif vote == 3:
        candidate3 = candidate3 + 1
        vote = int(input("Enter the ID number of the candidate (1-5, 0 to exit) : "))
    elif vote == 4:
        candidate4 = candidate4 + 1
        vote = int(input("Enter the ID number of the candidate (1-5, 0 to exit) : "))
    elif vote == 5:
        candidate5 = candidate5 + 1
        vote = int(input("Enter the ID number of the candidate (1-5, 0 to exit) : "))
    elif vote == 0:
        print("Thank you for voting!")
    else:
        print("That's not a valid candidate! Please try again.")
        vote = int(input("Enter the ID number of the candidate (1-5, 0 to exit) : "))
print ("\n And the votes are in! \n")

total = candidate1 + candidate2 + candidate3 + candidate4 + candidate5
print ("Candidate 1: " + str(candidate1) + " vote(s)")
print ("Candidate 2: " + str(candidate2) + " vote(s)")
print ("Candidate 3: " + str(candidate3) + " vote(s)")
print ("Candidate 4: " + str(candidate4) + " vote(s)")
print ("Candidate 5: " + str(candidate5) + " vote(s)")
print ("Total:      " + str(total) + "\n")
maxVote = 0
i = 0
if candidate1 > maxVote:
    maxVote = candidate1
    winner = "Candidate 1"
    i = i + 1
if candidate2 > maxVote:
    maxVote = candidate2
    winner = "Candidate 2"
    i = i + 1
if candidate3 > maxVote:
    maxVote = candidate3
    winner = "Candidate 3"
    i = i + 1
if candidate4 > maxVote:
    maxVote = candidate4
    winner = "Candidate 4"
    i = i + 1
if candidate5 > maxVote:
    maxVote = candidate5
    winner = "Candidate 5"
print ("*** Winner: " + winner + " ***")
