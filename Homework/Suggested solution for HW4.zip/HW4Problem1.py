# Suggested solution for HW 4, problem 1

x = 0
y = 0
command = 0
while command != 5:
    print("You are currently at (" + str(x) + ", " + str(y) + ")")
    command = int(input("Enter command: "))

    if command == 1:
        print("Moving north.")
        y = y + 1
    elif command == 2:
        print("Moving east.")
        x = x + 1
    elif command == 3:
        print("Moving south.")
        y = y - 1
    elif command == 4:
        print("Moving west.")
        x = x - 1
    elif command == 1337:
        print("Cheater!")
        x = 0
        y = 0
    elif command < 1 or command > 5:
        print("Hey, that's not a valid command!  Try again.")

print("kthxbye")
