# Suggested solution for HW 4, problem 2

# v1 through v5 keep track of how many votes each candidate has
v1 = 0
v2 = 0
v3 = 0
v4 = 0
v5 = 0

maxVotes = 0    # keeps track of the most votes by a single candidate
winner = 0      # keeps track of the winning candidate

who = 1
while who != 0:
    who = int(input("Enter the ID number of your candidate: "))

    if who == 1:
        v1 = v1 + 1
        if v1 > maxVotes:
            maxVotes = v1
            winner = 1
    elif who == 2:
        v2 = v2 + 1
        if v2 > maxVotes:
            maxVotes = v2
            winner = 2
    elif who == 3:
        v3 = v3 + 1
        if v3 > maxVotes:
            maxVotes = v3
            winner = 3
    elif who == 4:
        v4 = v4 + 1
        if v4 > maxVotes:
            maxVotes = v4
            winner = 4
    elif who == 5:
        v5 = v5 + 1
        if v5 > maxVotes:
            maxVotes = v5
            winner = 5
    elif who > 5 or who < 0:
        print("That's not a valid candidate!  Please try again.")

print("Candidate 1:  " + str(v1) + " vote(s)")
print("Candidate 2:  " + str(v2) + " vote(s)")
print("Candidate 3:  " + str(v3) + " vote(s)")
print("Candidate 4:  " + str(v4) + " vote(s)")
print("Candidate 5:  " + str(v5) + " vote(s)")

totalVotes = v1 + v2 + v3 + v4 + v5
print("Total votes:  " + str(totalVotes) + " vote(s)")
print("Max votes:    " + str(maxVotes))
print("Winner:       Candidate " + str(winner))
